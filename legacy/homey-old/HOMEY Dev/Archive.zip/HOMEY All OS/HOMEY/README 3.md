Share extension README
