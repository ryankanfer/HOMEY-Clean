Bridge README and instructions
