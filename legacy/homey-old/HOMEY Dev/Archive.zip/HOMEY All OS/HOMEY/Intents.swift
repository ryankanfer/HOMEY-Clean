/* SaveListingIntent, OpenInScoutIntent, AddNoteToListingIntent scaffolds */
