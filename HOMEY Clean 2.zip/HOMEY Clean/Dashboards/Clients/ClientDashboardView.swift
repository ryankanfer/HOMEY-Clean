import SwiftUI

public struct ClientDashboardView: View {
    private let logger: JourneyLogging?
    @EnvironmentObject private var flags: FeatureFlags

    public init(logger: JourneyLogging? = nil) { self.logger = logger }

    public var body: some View {
        if flags.useLegacyClientTabs {
            LegacyClientDashboardTabs()
        } else {
            SwipeClientDashboard(logger: logger)
        }
    }
}

// MARK: - New single-surface swipeable dashboard
private struct SwipeClientDashboard: View {
    let logger: JourneyLogging?
    @State private var page = 0
    private let titles = ["Charlie", "Paige", "Scout", "Isla", "Viza", "Drew"]

    var body: some View {
        VStack(spacing: 12) {
            // Header with current section title
            HStack {
                Text(titles[safe: page] ?? "Client")
                    .font(.largeTitle.bold())
                Spacer()
                BuildBadge()
            }
            .padding(.horizontal)

            TabView(selection: $page) {
                CharlieSection().tag(0)
                PaigeSection().tag(1)
                ScoutSection().tag(2)
                IslaSection().tag(3)
                VizaSection().tag(4)
                DrewSection().tag(5)
            }
            .tabViewStyle(.page(indexDisplayMode: .always))
        }
        .onAppear { logger?.log("Viewed Dashboard: Client", metadata: ["screen": "client"]) }
    }
}

// MARK: - Section stubs (replace with real content or paste legacy UI into each)
private struct CharlieSection: View {
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            SectionCard(title: "Charlie’s Corner", subtitle: "Education & prep") {
                PlaceholderRow(label: "Education Center")
                PlaceholderRow(label: "Chat with Charlie")
            }
        }.padding() }
    }
}

private struct PaigeSection: View {
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            SectionCard(title: "Paige’s Paperwork", subtitle: "Tasks & docs") {
                PlaceholderRow(label: "Document readiness")
                PlaceholderRow(label: "Smart upload")
                PlaceholderRow(label: "Documents")
            }
        }.padding() }
    }
}

private struct ScoutSection: View {
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            SectionCard(title: "Scout’s Searches", subtitle: "Find & shortlist") {
                PlaceholderRow(label: "Search homes")
                PlaceholderRow(label: "Closing Time game")
                PlaceholderRow(label: "View matches")
            }
        }.padding() }
    }
}

private struct IslaSection: View {
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            SectionCard(title: "Isla’s Insights", subtitle: "Neighborhood stats") {
                PlaceholderRow(label: "Area vs baseline metrics")
                PlaceholderRow(label: "More insights")
            }
        }.padding() }
    }
}

private struct VizaSection: View {
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            SectionCard(title: "Viza Vision", subtitle: "Design & vibes") {
                PlaceholderRow(label: "Design inspiration")
                PlaceholderRow(label: "Chat with Viza")
                PlaceholderRow(label: "Upload photo")
            }
        }.padding() }
    }
}

private struct DrewSection: View {
    var body: some View {
        ScrollView { VStack(alignment: .leading, spacing: 16) {
            SectionCard(title: "Drew Directory", subtitle: "Trusted pros") {
                PlaceholderRow(label: "Lenders")
                PlaceholderRow(label: "Inspectors")
                PlaceholderRow(label: "Movers")
            }
        }.padding() }
    }
}

// MARK: - Reused UI pieces
private struct SectionCard<Content: View>: View {
    let title: String
    let subtitle: String
    @ViewBuilder var content: Content
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(title).font(.title3).bold()
                Text(subtitle).font(.subheadline).foregroundStyle(.secondary)
            }
            content
        }
        .padding()
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
    }
}

private struct PlaceholderRow: View {
    let label: String
    var body: some View {
        HStack {
            Circle().frame(width: 10, height: 10)
            Text(label)
            Spacer()
            Text("—").foregroundStyle(.secondary)
        }.font(.subheadline)
    }
}

// MARK: - Safe index helper
private extension Array {
    subscript(safe index: Int) -> Element? { indices.contains(index) ? self[index] : nil }
}
