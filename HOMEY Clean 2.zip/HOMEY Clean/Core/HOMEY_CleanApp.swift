import SwiftUI
#if canImport(Supabase)
import Supabase
#endif

@main
struct HOMEY_CleanApp: App {
    @StateObject private var session: AppSessionManager

    init() {
        #if canImport(Supabase)
        // TODO: replace with your real URL/key, or inject via config
        let url = URL(string: "hhttps://fafbjfajmmsjftiivhil.supabase.co")!
        let key = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImZhZmJqZmFqbW1zamZ0aWl2aGlsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIxODg4MjEsImV4cCI6MjA2Nzc2NDgyMX0.S9P5wgPZGBop-0E55VMD1mhfIe2PnJfq28nt8UMLjCM"
        _session = StateObject(wrappedValue: AppSessionManager(
            client: SupabaseClient(supabaseURL: url, supabaseKey: key)
        ))
        #else
        _session = StateObject(wrappedValue: AppSessionManager(profiles: FakeProfilesService()))
        #endif
    }

    var body: some Scene {
        WindowGroup {
            RootView()
                .environmentObject(session)
                .task {
                    // Try to hydrate any existing session on launch
                    await session.restoreIfPossible()
                }
        }
    }
}
