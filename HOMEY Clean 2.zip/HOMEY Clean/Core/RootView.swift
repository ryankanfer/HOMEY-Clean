import SwiftUI

struct RootView: View {
    @EnvironmentObject private var session: AppSessionManager
    @AppStorage("hasSeenCharlieOnboarding") private var hasSeenCharlieOnboarding = false
    @State private var showCharlie = false
    @State private var splashDone = false  // if you run a splash

    var body: some View {
        Group {
            if session.isAuthenticated {
                AuthenticatedHome()
                    .sheet(isPresented: $showCharlie) {
                        CharlieOnboardingView {
                            hasSeenCharlieOnboarding = true
                            showCharlie = false
                        }
                        .environmentObject(session)
                    }
                    .task(id: session.isAuthenticated) {
                        if session.isAuthenticated,
                           !hasSeenCharlieOnboarding {
                            if splashDone == false { try? await Task.sleep(nanoseconds: 800_000_000) }
                            showCharlie = true
                        }
                    }
            } else {
                AuthGate()
            }
        }
        .journeyWatched()
        .onAppear { splashDone = true }
    }
}

// MARK: - Logged-out shell
private struct AuthGate: View {
    var body: some View {
        VStack(spacing: 16) {
            Text("Please sign in")
                .font(.title2.weight(.semibold))
            Text("Wire your Login/CreateAccount views here.")
                .multilineTextAlignment(.center)
                .foregroundStyle(.secondary)
        }
        .padding()
    }
}

// MARK: - Logged-in shell
private struct AuthenticatedHome: View {
    @EnvironmentObject private var session: AppSessionManager

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 16) {
                    Text("HOMEY")
                        .font(.largeTitle.bold())

                    RoleSelectionView()

                    Divider()

                    Group {
                        Text("Current role: \(session.userRole.capitalized)")
                        if session.userRole == "client" {
                            Text("Client segment: \(session.clientSegment?.capitalized ?? "—")")
                        }
                    }
                    .font(.callout)
                    .foregroundStyle(.secondary)

                    Group {
                        switch session.userRole {
                        case "agent":
                            AgentArea()
                        case "admin":
                            AdminArea()
                        default:
                            ClientArea()
                        }
                    }
                    .padding(.top, 8)

                    Button("Sign Out") {
                        Task { await session.signOut() }
                    }
                    .buttonStyle(.bordered)
                    .padding(.top, 16)
                }
                .padding()
            }
            .navigationTitle("Dashboard")
        }
    }
}

private struct ClientArea: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Client Area")
                .font(.title3.weight(.semibold))
            Text("Drop ClientDashboardView here.")
                .foregroundStyle(.secondary)
        }
    }
}

private struct AgentArea: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Agent Area")
                .font(.title3.weight(.semibold))
            Text("Drop AgentDashboardView here.")
                .foregroundStyle(.secondary)
        }
    }
}

private struct AdminArea: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Admin Area")
                .font(.title3.weight(.semibold))
            Text("Drop AdminDashboardView here.")
                .foregroundStyle(.secondary)
        }
    }
}
