import Foundation

extension AppSessionManager {
    /// Switch the active role locally, and optionally persist if needed.
    @MainActor
    func setActiveRole(_ role: String) async throws {
        // If you keep roles in public.profiles, you can persist here:
        // try await profiles.updateRole(role)
        // For now we just set and notify.
        self.userRole = role
        self.objectWillChange.send()
    }
}
